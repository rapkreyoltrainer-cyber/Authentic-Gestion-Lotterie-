package com.authentic.gestionlotterie;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private final int navy = Color.rgb(15, 35, 65);
    private final int gold = Color.rgb(225, 174, 55);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        showHome();
    }

    private void setup(String subtitle) {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 30, 24, 30);
        root.setBackgroundColor(Color.rgb(245,247,250));
        scroll.addView(root);
        setContentView(scroll);
        TextView brand = new TextView(this);
        brand.setText("AUTHENTIC\\nGESTION LOTTERIE");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(25);
        brand.setTypeface(null, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(12,25,12,25);
        brand.setBackgroundColor(navy);
        root.addView(brand, match());
        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextColor(navy);
        sub.setTextSize(18);
        sub.setTypeface(null, Typeface.BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(8,22,8,18);
        root.addView(sub, match());
        TextView demo = new TextView(this);
        demo.setText("VERSION DEMO — DONNÉES FICTIVES");
        demo.setTextColor(Color.rgb(150,80,0));
        demo.setGravity(Gravity.CENTER);
        demo.setTextSize(12);
        demo.setPadding(8,4,8,18);
        root.addView(demo, match());
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private void addButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(navy));
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, 8, 0, 8);
        root.addView(b,p);
        b.setOnClickListener(v -> action.run());
    }

    private void addText(String value) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.DKGRAY);
        t.setTextSize(16);
        t.setPadding(8,12,8,12);
        root.addView(t, match());
    }

    private void showHome() {
        setup("Chwazi espas ou");
        addText("Twa aksè diferan pou twa kalite itilizatè.");
        addButton("ESPACE PROPRIÉTAIRE", () -> showLogin("Pwopriyetè"));
        addButton("ESPACE ADMINISTRATEUR COMPAGNIE", () -> showLogin("Administratè konpayi"));
        addButton("ESPACE AGENT POS", () -> showLogin("Ajan POS"));
        addText("Demo sa a montre navigasyon ak aparans. Koneksyon, lavant ak senkronizasyon reyèl poko aktive.");
    }

    private void showLogin(String role) {
        setup("Koneksyon — " + role);
        addText("Antre demonstrasyon. Pa itilize modpas reyèl.");
        EditText username = new EditText(this);
        username.setHint("Non itilizatè demo");
        root.addView(username, match());
        EditText password = new EditText(this);
        password.setHint("Modpas demo");
        password.setInputType(129);
        root.addView(password, match());
        addButton("Antre nan espas la", () -> showDashboard(role));
        addButton("Retounen", this::showHome);
    }

    private void showDashboard(String role) {
        setup("Tablo de bord — " + role);
        if (role.equals("Pwopriyetè")) {
            addText("Jere tout konpayi yo (egzanp demo)");
            addButton("Lis konpayi yo", () -> showInfo(role, "Konpayi Demo A\\nKonpayi Demo B\\nKonpayi Demo C"));
            addButton("Ajan ak POS", () -> showInfo(role, "Ajan demo: 12\\nPOS demo: 8"));
            addButton("Abònman ak lisans", () -> showInfo(role, "Estati demo: Aktivite tès"));
            addButton("Tiraj ak rezilta", () -> showInfo(role, "Rezilta demonstrasyon: 12 - 24 - 08"));
        } else if (role.equals("Administratè konpayi")) {
            addText("Konpayi pa w sèlman (done demonstrasyon)");
            addButton("Ajan konpayi an", () -> showInfo(role, "Ajan demo: 4"));
            addButton("Pwen lavant POS", () -> showInfo(role, "POS demo: 3"));
            addButton("Vant ak rapò", () -> showInfo(role, "Vant jodi a: 0.00 (demo)"));
            addButton("Paramèt konpayi", () -> showInfo(role, "Paramèt tès konpayi"));
        } else {
            addText("Zouti ajan POS");
            addButton("Nouvo tikè (demo)", () -> showInfo(role, "Fonksyon lavant la poko konekte ak sèvè."));
            addButton("Tiraj ak rezilta", () -> showInfo(role, "Rezilta demo: 12 - 24 - 08"));
            addButton("Rapò lavant mwen", () -> showInfo(role, "Pa gen lavant reyèl nan vèsyon demo."));
            addButton("Istwa tikè", () -> showInfo(role, "Istwa tikè demo vid."));
        }
        addButton("Dekonekte", this::showHome);
    }

    private void showInfo(String role, String message) {
        setup(role);
        addText(message);
        addButton("Retounen nan tablo de bord", () -> showDashboard(role));
        addButton("Dekonekte", this::showHome);
    }
}
